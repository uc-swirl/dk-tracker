# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rottenpotatoes::Application.config.secret_token = 'b30ce7653f6d66af1607e6185f8de9d5923fa45975b2fefc587ea69550cb5e7a7d8470eacc4302fc5b40e76f8c79bf3c5d4f935e4d9a1b32dd3ac2e92e03634b'
